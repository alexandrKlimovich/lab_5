package org.example;
import entity.Payment;

//2. Создать класс Payment с внутренним классом,
// с помощью объектов которого можно
// сформировать покупку из нескольких товаров.

public class Main {
    public static void main(String[] args) {
        Payment payment = new Payment();
        payment.addProduct("Phone case", 10.0, 2);
        payment.addProduct("Charger", 15.0, 1);
        payment.addProduct("Protective glass", 10.0, 2);

        double totalAmount = payment.getTotalAmount();
        System.out.println("Total amount: " + totalAmount);

        payment.makePayment(totalAmount);
    }
}