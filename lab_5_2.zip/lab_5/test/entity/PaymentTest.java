package entity;

import entity.Payment;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

class PaymentTest {
    private Payment payment;

    @BeforeMethod
    public void setUp() {
        payment = new Payment();
    }

    @Test
    public void testAddProduct() {
        payment.addProduct("Phone case", 10.0, 2);
        payment.addProduct("Charger", 15.0, 1);

        Assert.assertEquals(payment.getTotalAmount(), 35.0);
    }

    @Test
    public void testGetTotalAmount() {
        payment.addProduct("Phone case", 10.0, 2);
        payment.addProduct("Charger", 15.0, 1);

        Assert.assertEquals(payment.getTotalAmount(), 35.0);
    }

    @Test
    public void testMakePayment() {
        payment.addProduct("Phone case", 10.0, 2);
        payment.addProduct("Charger", 15.0, 1);

        double totalAmount = payment.getTotalAmount();
        payment.makePayment(totalAmount);
    }
}